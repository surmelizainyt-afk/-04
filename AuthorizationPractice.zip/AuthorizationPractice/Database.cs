namespace AuthorizationPractice
{
    /// <summary>
    /// Хранит строку подключения к базе данных AuthorizationPractice.
    /// </summary>
    public static class Database
    {
        public static string ConnectionString =>
            @"Server=.\SQLEXPRESS;Database=AuthorizationPractice;Trusted_Connection=True;";
    }
}
