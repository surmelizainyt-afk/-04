using System.Windows;
using AuthorizationPractice.Models;

namespace AuthorizationPractice
{
    public partial class MainWindow : Window
    {
        private readonly User _currentUser;

        public MainWindow(User user)
        {
            InitializeComponent();
            _currentUser = user;
            DisplayUserInfo();
        }

        private void DisplayUserInfo()
        {
            FullNameText.Text = _currentUser.FullName;
            LoginText.Text = _currentUser.Login;
            RoleText.Text = _currentUser.RoleName;
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            this.Close();
        }
    }
}
