﻿/*
  AuthorizationPractice — учебная БД для WPF + ADO.NET.
  SQL Server 2022 Express.
  Пароли тестовые; в PasswordHash хранятся PBKDF2-хеши.
  Формат совместим с Rfc2898DeriveBytes в .NET Framework 4.7.
*/
USE master;
GO
IF DB_ID(N'AuthorizationPractice') IS NULL
    CREATE DATABASE AuthorizationPractice;
GO
USE AuthorizationPractice;
GO

IF OBJECT_ID(N'dbo.Roles', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Roles
    (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(50) NOT NULL UNIQUE
    );
END;
GO

IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users
    (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Login NVARCHAR(50) NOT NULL UNIQUE,
        PasswordHash NVARCHAR(255) NOT NULL,
        FullName NVARCHAR(150) NOT NULL,
        RoleId INT NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_Users_IsActive DEFAULT (1),
        CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleId) REFERENCES dbo.Roles(Id)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Roles WHERE Name=N'Администратор')
    INSERT INTO dbo.Roles(Name) VALUES (N'Администратор');
IF NOT EXISTS (SELECT 1 FROM dbo.Roles WHERE Name=N'Специалист')
    INSERT INTO dbo.Roles(Name) VALUES (N'Специалист');
IF NOT EXISTS (SELECT 1 FROM dbo.Roles WHERE Name=N'Пользователь')
    INSERT INTO dbo.Roles(Name) VALUES (N'Пользователь');
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Login=N'admin')
    INSERT INTO dbo.Users(Login,PasswordHash,FullName,RoleId,IsActive)
    SELECT N'admin',N'100000.ECEyQ1RldoeYqbrL3O3+Dw==.TtxZlSIkaWJ3dApOzRG0aHJ6Ts46TLAaYpMPaJf+yzQ=',N'Александр Администраторов',Id,1
    FROM dbo.Roles WHERE Name=N'Администратор';

IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Login=N'support1')
    INSERT INTO dbo.Users(Login,PasswordHash,FullName,RoleId,IsActive)
    SELECT N'support1',N'100000.IDFCU2R1hpeoucrb7P0OHw==.Vp9PB3nMg4ruDxsM3xCkKCcqZ0ae5mvhPRokVTv83+A=',N'Мария Специалистова',Id,1
    FROM dbo.Roles WHERE Name=N'Специалист';

IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Login=N'user1')
    INSERT INTO dbo.Users(Login,PasswordHash,FullName,RoleId,IsActive)
    SELECT N'user1',N'100000.MEFSY3SFlqe4ydrr/A0eLw==.7yoeTvZ5izRr90E8kRYYHYDAuRjnG4d3zEPGt+vJ3BI=',N'Иван Пользователь',Id,1
    FROM dbo.Roles WHERE Name=N'Пользователь';
GO

SELECT u.Id,u.Login,u.FullName,r.Name AS RoleName,u.IsActive
FROM dbo.Users u
INNER JOIN dbo.Roles r ON r.Id=u.RoleId
ORDER BY u.Id;
GO
PRINT N'База AuthorizationPractice создана и заполнена.';
GO
